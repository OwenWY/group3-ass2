﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ResumeBuilder
{
    public partial class Login : ContentPage
    {
        public Login()
        {
            InitializeComponent();

            #if _Android_
                TranslationY = 
        }

    }
}
