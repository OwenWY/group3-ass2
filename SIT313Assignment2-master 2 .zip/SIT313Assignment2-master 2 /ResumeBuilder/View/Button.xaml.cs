﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ResumeBuilder.View
{
    public partial class Button : ContentPage
    {
        public Button()
        {
            InitializeComponent();
        }
    }
}
