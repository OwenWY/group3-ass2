﻿using System;
namespace ResumeBuilder.Model
{
    public class SessionInfoData
    {

    }
}
