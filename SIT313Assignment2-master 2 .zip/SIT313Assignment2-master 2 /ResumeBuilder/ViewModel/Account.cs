﻿using System;
namespace ResumeBuilder.ViewModel
{
    public class Account
    {
        public Account()
        {
        }
    }
}
