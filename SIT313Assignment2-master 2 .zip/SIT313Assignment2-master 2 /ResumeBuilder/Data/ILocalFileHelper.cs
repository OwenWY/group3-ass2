﻿using System;
namespace ResumeBuilder.Data
{
    public interface ILocalFileHelper
    {
        string GetLocalFilePath(string fileName);
    }
}
